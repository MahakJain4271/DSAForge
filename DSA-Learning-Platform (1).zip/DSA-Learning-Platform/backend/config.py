# backend/config.py
DB_HOST = "localhost"
DB_USER = "root"
DB_PASSWORD = "root123"  # use your actual password
DB_NAME = "dsa_platform"
DB_PORT = 3307  # ✅ make sure to add this line
